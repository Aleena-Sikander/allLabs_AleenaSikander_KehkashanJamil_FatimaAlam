module tb_instructionMemory;

    reg  [31:0] current_addr;
    wire [31:0] fetched_instr;

    // Instantiate the Instruction Memory module
    instructionMemory uut (
    .instAddress(current_addr), 
    .instruction(fetched_instr)
    );

    initial begin
        // Display header for simulation output
        $display("Addr | Instruction | Expected Operation");
        $display("-----+-------------+-------------------");

        // Input polling loop instructions
        current_addr = 0;  #10; $display("0x%02h | 0x%08h | li   t0, 0x200    (poll_input)", current_addr, fetched_instr);
        current_addr = 4;  #10; $display("0x%02h | 0x%08h | lw   t1, 0(t0)", current_addr, fetched_instr);
        current_addr = 8;  #10; $display("0x%02h | 0x%08h | beq  t1, zero, poll_input", current_addr, fetched_instr);
        current_addr = 12; #10; $display("0x%02h | 0x%08h | mv   a0, t1", current_addr, fetched_instr);
        current_addr = 16; #10; $display("0x%02h | 0x%08h | jal  ra, start_timer", current_addr, fetched_instr);
        current_addr = 20; #10; $display("0x%02h | 0x%08h | j    poll_input", current_addr, fetched_instr);

        // Timer initialization routine
        current_addr = 24; #10; $display("0x%02h | 0x%08h | addi sp, sp, -8   (start_timer)", current_addr, fetched_instr);
        current_addr = 28; #10; $display("0x%02h | 0x%08h | sw   ra, 4(sp)", current_addr, fetched_instr);
        current_addr = 32; #10; $display("0x%02h | 0x%08h | sw   s0, 0(sp)", current_addr, fetched_instr);
        current_addr = 36; #10; $display("0x%02h | 0x%08h | mv   s0, a0", current_addr, fetched_instr);
        current_addr = 40; #10; $display("0x%02h | 0x%08h | li   t0, 0x100", current_addr, fetched_instr);

        // Display update loop
        current_addr = 44; #10; $display("0x%02h | 0x%08h | sw   s0, 0(t0)    (refresh_display)", current_addr, fetched_instr);
        current_addr = 48; #10; $display("0x%02h | 0x%08h | li   t2, 0x200", current_addr, fetched_instr);
        current_addr = 52; #10; $display("0x%02h | 0x%08h | lw   s1, 0(t2)", current_addr, fetched_instr);
        current_addr = 56; #10; $display("0x%02h | 0x%08h | bne  s1, zero, system_reset", current_addr, fetched_instr);
        current_addr = 60; #10; $display("0x%02h | 0x%08h | lui  t3, 488", current_addr, fetched_instr);
        current_addr = 64; #10; $display("0x%02h | 0x%08h | addi t3, t3, 1152", current_addr, fetched_instr);

        // Delay loop for timing control
        current_addr = 68; #10; $display("0x%02h | 0x%08h | addi t3, t3, -1   (wait_state)", current_addr, fetched_instr);
        current_addr = 72; #10; $display("0x%02h | 0x%08h | bne  t3, zero, wait_state", current_addr, fetched_instr);

        // Counter decrement and loop control
        current_addr = 76; #10; $display("0x%02h | 0x%08h | addi s0, s0, -1", current_addr, fetched_instr);
        current_addr = 80; #10; $display("0x%02h | 0x%08h | bge  s0, zero, refresh_display", current_addr, fetched_instr);

        // System reset sequence
        current_addr = 100; #10; $display("0x%02h | 0x%08h | sw   zero, 0(t0) (system_reset)", current_addr, fetched_instr);
        current_addr = 116; #10; $display("0x%02h | 0x%08h | j    poll_input", current_addr, fetched_instr);

        $finish;
    end
endmodule