`timescale 1ns / 1ps

module MemorySystem_tb(); 
reg clk; 
reg rst; 
reg readEnable; 
reg writeEnable; 
reg [31:0] address; 
reg [31:0] writeData; 
reg [15:0] switches; 
wire [31:0] readData; 
wire [15:0] leds; 
addressDecoderTop uut( 
    .clk(clk), .rst(rst), 
    .address(address), 
    .readEnable(readEnable), 
    .writeEnable(writeEnable), 
    .writeData(writeData), 
    .switches(switches), 
    .readData(readData), 
    .leds(leds) ); 

/* Clock */ 
always #5 clk = ~clk; initial begin 
    clk = 0; 
    rst = 0;
     
    /* Initialize */ 
    readEnable = 0; 
    writeEnable = 0; 
    address = 0; 
    writeData = 0; 
    switches = 16'hAAAA; 
    
    #10; 
    
    /* Write to Data Memory */ 
    address = 32'd100; // inside 0-511 
    writeData = 32'hDEADBEEF; 
    writeEnable = 1; #10; writeEnable = 0; 
    
    /* Read from Data Memory */ 
    readEnable = 1; #10; readEnable = 0; 
    
    /* Write to LEDs */ 
    address = 32'd520; // inside 512-767 
    writeData = 32'h000000FF; 
    writeEnable = 1; #10; 
    writeEnable = 0; 
    
    /* Read from Switches */ 
    address = 32'd800; // inside 768-1023 
    readEnable = 1; #10; 
    readEnable = 0; #20; $finish; 
end 
endmodule
