`timescale 1ns / 1ps

module debouncer (
    input  wire clk,
    input  wire pbtn_in,
    output wire pbtn_out
);
    reg [19:0] shift_reg = 0;
    always @(posedge clk) shift_reg <= {shift_reg[18:0], pbtn_in};
    assign pbtn_out = &shift_reg;  // all 1s = stable high
endmodule