`timescale 1ns / 1ps

module led(
    input clk,
    input rst,
    input [31:0]writeData,
    input writeEnable,
    input [29:0] memAddress,
    output reg [31:0] readData=0,
    output reg [15:0] leds
    );
    
//    reg [7:0] ledData [3:0];
    reg [7:0] ledData [0:1];
//    always @(posedge clk) begin
//        if (writeEnable) begin
//            ledData[0]<= writeData[7:0];
//            ledData[1]<=writeData[15:8];
//        end
//    end
    always @(posedge clk) begin
    if (rst) begin
        ledData[0] <= 8'd0;
        ledData[1] <= 8'd0;
        leds       <= 16'd0;
        readData   <= 32'd0;
    end
    else if (writeEnable) begin
        ledData[0] <= writeData[7:0];
        ledData[1] <= writeData[15:8];
        leds       <= writeData[15:0];          
        readData   <= 32'd0;
    end
end
    
//    always @(*) begin
//        if (rst) leds = 16'b0;
//        else leds = {ledData[1], ledData[0]};
//        end    
endmodule
