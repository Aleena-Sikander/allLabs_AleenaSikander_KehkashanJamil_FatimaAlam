`timescale 1ns / 1ps

module top (
    input  wire        clk,          // CLK100MHZ (W5)
    input  wire        btnC,         // Center = reset
    input  wire        btnU, btnD, btnL, btnR,
    input  wire [15:0] sw,
    output wire [15:0] led,
    output wire [6:0]  seg,
    output wire [3:0]  an
);

    // Debounce all buttons
    wire rst_db, btnU_db, btnD_db, btnL_db, btnR_db;
    debouncer db_rst   (.clk(clk), .pbtn_in(btnC), .pbtn_out(rst_db));
    debouncer db_up    (.clk(clk), .pbtn_in(btnU), .pbtn_out(btnU_db));
    debouncer db_down  (.clk(clk), .pbtn_in(btnD), .pbtn_out(btnD_db));
    debouncer db_left  (.clk(clk), .pbtn_in(btnL), .pbtn_out(btnL_db));
    debouncer db_right (.clk(clk), .pbtn_in(btnR), .pbtn_out(btnR_db));

    // Edge detect (pulse on rising edge)
    reg btnU_prev, btnD_prev, btnL_prev, btnR_prev;
    wire btnU_pulse = btnU_db & ~btnU_prev;
    wire btnD_pulse = btnD_db & ~btnD_prev;
    wire btnL_pulse = btnL_db & ~btnL_prev;
    wire btnR_pulse = btnR_db & ~btnR_prev;

    always @(posedge clk) begin
        btnU_prev <= btnU_db;
        btnD_prev <= btnD_db;
        btnL_prev <= btnL_db;
        btnR_prev <= btnR_db;
    end

    // Mode register (0=DM write, 1=LED write, 2=DM read, 3=Switch read)
    reg [1:0] mode = 0;
    always @(posedge clk or posedge rst_db) begin
        if (rst_db) mode <= 0;
        else if (btnU_pulse) mode <= (mode == 3) ? 0 : mode + 1;
        else if (btnD_pulse) mode <= (mode == 0) ? 3 : mode - 1;
    end

    // Address & data from switches
    wire [31:0] addr_dm   = {22'b0, 2'b00, sw[15:8]};   // DM range
    wire [31:0] addr_led  = 32'h0000_0208;               // 520 = 0x208 (LED range)
    wire [31:0] addr_sw   = 32'h0000_0320;               // 800 = 0x320 (Switch range)
    wire [31:0] write_val = {24'b0, sw[7:0]};

    // CPU signals
    reg [31:0] address_r;
    reg        readEnable_r, writeEnable_r;
    reg [31:0] writeData_r;
    reg [15:0] display_reg;

    always @(posedge clk or posedge rst_db) begin
        if (rst_db) begin
            address_r    <= 0;
            readEnable_r <= 0;
            writeEnable_r<= 0;
            writeData_r  <= 0;
            display_reg  <= 0;
        end else begin
            readEnable_r  <= 0;
            writeEnable_r <= 0;

            case (mode)
                0: begin // Write Data Memory
                    address_r   <= addr_dm;
                    writeData_r <= write_val;
                    if (btnL_pulse) writeEnable_r <= 1;
                end
                1: begin // Write LEDs
                    address_r   <= addr_led;
                    writeData_r <= write_val;
                    if (btnL_pulse) writeEnable_r <= 1;
                end
                2: begin // Read Data Memory
                    address_r <= addr_dm;
                    if (btnR_pulse) readEnable_r <= 1;
                end
                3: begin // Read Switches
                    address_r <= addr_sw;
                    if (btnR_pulse) readEnable_r <= 1;
                end
            endcase

            if (readEnable_r) display_reg <= readData[15:0];
        end
    end

    // Instantiate your memory system
    wire [31:0] readData;
    wire [15:0] mem_leds;

    addressDecoderTop dut (
        .clk         (clk),
        .rst         (rst_db),
        .address     (address_r),
        .readEnable  (readEnable_r),
        .writeEnable (writeEnable_r),
        .writeData   (writeData_r),
        .switches    (sw),
        .readData    (readData),
        .leds        (mem_leds)
    );

    // LED output: show physical LEDs only in LED-write mode, else last result
    assign led = (mode == 1) ? mem_leds : display_reg;

    // 7-segment display (mode | address | data)
    // (You already have the 7-seg code from worksheet pages 15-16 - just copy it here)

endmodule