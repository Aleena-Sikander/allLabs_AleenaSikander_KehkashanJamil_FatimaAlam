`timescale 1ns/1ps

module ControlPath_tb;

    //MainControl signals 
    reg  [6:0] opcode;
    wire       RegWrite;
    wire [1:0] ALUOp;
    wire       MemRead, MemWrite, ALUSrc, MemtoReg, Branch;

    //ALUControl signals
    reg  [1:0] aluop_in;
    reg  [2:0] funct3;
    reg        funct7_bit;
    wire [3:0] ALUControlOut;

    //Instantiate MainControl
    MainControl DUT_MC (
        .opcode   (opcode),
        .RegWrite (RegWrite),
        .ALUOp    (ALUOp),
        .MemRead  (MemRead),
        .MemWrite (MemWrite),
        .ALUSrc   (ALUSrc),
        .MemtoReg (MemtoReg),
        .Branch   (Branch)
    );

    //Instantiate ALUControl
    ALUControl DUT_AC (
        .ALUOp        (aluop_in),
        .funct3       (funct3),
        .funct7_bit   (funct7_bit),
        .ALUControlOut(ALUControlOut)
    );

    initial begin

        //initialise all inputs
        opcode     = 7'b0000000;
        aluop_in   = 2'b00;
        funct3     = 3'b000;
        funct7_bit = 1'b0;

        #10;

        //MAIN CONTROL 

        //R-type
        opcode = 7'b0110011; #10;

        //I-type ALU
        opcode = 7'b0010011; #10;

        //Load
        opcode = 7'b0000011; #10;

        //Store
        opcode = 7'b0100011; #10;

        //Branch
        opcode = 7'b1100011; #10;

        //Unknown opcode
        opcode = 7'b1111111; #10;

        //ALU CONTROL

        // Load / Store -> ADD
        aluop_in = 2'b00; funct3 = 3'b000; funct7_bit = 1'b0; #10;

        // BEQ -> SUB
        aluop_in = 2'b01; funct3 = 3'b000; funct7_bit = 1'b0; #10;

        // ADD  funct3=000 funct7[30]=0
        aluop_in = 2'b10; funct3 = 3'b000; funct7_bit = 1'b0; #10;

        // SUB  funct3=000 funct7[30]=1
        aluop_in = 2'b10; funct3 = 3'b000; funct7_bit = 1'b1; #10;

        // AND  funct3=111
        aluop_in = 2'b10; funct3 = 3'b111; funct7_bit = 1'b0; #10;

        // OR   funct3=110
        aluop_in = 2'b10; funct3 = 3'b110; funct7_bit = 1'b0; #10;

        // XOR  funct3=100
        aluop_in = 2'b10; funct3 = 3'b100; funct7_bit = 1'b0; #10;

        // SLL  funct3=001
        aluop_in = 2'b10; funct3 = 3'b001; funct7_bit = 1'b0; #10;

        // SRL  funct3=101
        aluop_in = 2'b10; funct3 = 3'b101; funct7_bit = 1'b0; #10;

        // ADDI funct3=000 funct7[30]=0  (I-type, bit[30] is always 0)
        aluop_in = 2'b10; funct3 = 3'b000; funct7_bit = 1'b0; #10;

        //INTEGRATION

        // LW
        opcode = 7'b0000011; aluop_in = 2'b00;
        funct3 = 3'b010; funct7_bit = 1'b0; #10;

        // LH
        opcode = 7'b0000011; aluop_in = 2'b00;
        funct3 = 3'b001; funct7_bit = 1'b0; #10;

        // LB
        opcode = 7'b0000011; aluop_in = 2'b00;
        funct3 = 3'b000; funct7_bit = 1'b0; #10;

        // SW
        opcode = 7'b0100011; aluop_in = 2'b00;
        funct3 = 3'b010; funct7_bit = 1'b0; #10;

        // SH
        opcode = 7'b0100011; aluop_in = 2'b00;
        funct3 = 3'b001; funct7_bit = 1'b0; #10;

        // SB
        opcode = 7'b0100011; aluop_in = 2'b00;
        funct3 = 3'b000; funct7_bit = 1'b0; #10;

        // BEQ
        opcode = 7'b1100011; aluop_in = 2'b01;
        funct3 = 3'b000; funct7_bit = 1'b0; #10;

        $finish;
    end

endmodule