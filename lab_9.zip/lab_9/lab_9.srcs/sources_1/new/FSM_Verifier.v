`timescale 1ns/1ps


module FSM_Verifier (
    input clk,
    input rst,
    input btn_next,   // BTN[0]: advance to next state
    input btn_reset,  // BTN[1]: return to IDLE

    // Outputs to MainControl + ALUControl
    output reg [6:0] opcode,
    output reg [2:0] funct3,
    output reg funct7_bit,

    // State indicator on 4 LEDs (state index 0-15)
    output reg [3:0] state_led
);

    //State encoding
    localparam [3:0]
        IDLE = 4'd0,
        ADD = 4'd1,
        SUB = 4'd2,
        ADDI = 4'd3,
        AND = 4'd4,
        OR_S= 4'd5,
        XOR_S= 4'd6,
        SLL_S= 4'd7,
        SRL_S= 4'd8,
        LW_S = 4'd9,
        LH_S = 4'd10,
        LB_S = 4'd11,
        SW_ST= 4'd12,
        SH_S = 4'd13,
        SB_S = 4'd14,
        BEQ_S= 4'd15;

    reg [3:0] state, next_state;

    //Edge-detect btn_next 
    reg btn_prev;
    wire btn_rise = btn_next & ~btn_prev;

    always @(posedge clk or posedge rst) begin
        if (rst) btn_prev <= 1'b0;
        else btn_prev <= btn_next;
    end

    //State register 
    always @(posedge clk or posedge rst) begin
        if (rst || btn_reset)
            state <= IDLE;
        else if (btn_rise)
            state <= next_state;
    end

    //Next-state logic 
    always @(*) begin
        case (state)
            IDLE:next_state = ADD;
            ADD:next_state = SUB;
            SUB:next_state = ADDI;
            ADDI:next_state = AND;
            AND: next_state = OR_S;
            OR_S:next_state = XOR_S;
            XOR_S:next_state = SLL_S;
            SLL_S:next_state = SRL_S;
            SRL_S: next_state = LW_S;
            LW_S:next_state = LH_S;
            LH_S:next_state = LB_S;
            LB_S: next_state = SW_ST;
            SW_ST:next_state = SH_S;
            SH_S:next_state = SB_S;
            SB_S: next_state = BEQ_S;
            BEQ_S: next_state = IDLE;
            default: next_state = IDLE;
        endcase
    end

    //Output logic (Moore)
    always @(*) begin
        //defaults
        opcode = 7'b0000000;
        funct3 = 3'b000;
        funct7_bit = 1'b0;
        state_led = state;

        case (state)
            IDLE: begin
                opcode = 7'b0000000;
            end

            //R-type instructions
            ADD: begin
                opcode = 7'b0110011; 
                funct3 = 3'b000;
                funct7_bit = 1'b0;        
            end
            SUB: begin
                opcode = 7'b0110011;
                funct3 = 3'b000;
                funct7_bit = 1'b1;       
            end
            AND: begin
                opcode = 7'b0110011;
                funct3 = 3'b111;
                funct7_bit = 1'b0;
            end
            OR_S: begin
                opcode = 7'b0110011;
                funct3 = 3'b110;
                funct7_bit = 1'b0;
            end
            XOR_S: begin
                opcode = 7'b0110011;
                funct3 = 3'b100;
                funct7_bit = 1'b0;
            end
            SLL_S: begin
                opcode = 7'b0110011;
                funct3= 3'b001;
                funct7_bit = 1'b0;
            end
            SRL_S: begin
                opcode = 7'b0110011;
                funct3 = 3'b101;
                funct7_bit = 1'b0;
            end

            //I-type ALU
            ADDI: begin
                opcode = 7'b0010011;
                funct3 = 3'b000;
                funct7_bit = 1'b0;
            end

            //Load instructions
            LW_S: begin
                opcode = 7'b0000011;
                funct3 = 3'b010;      
                funct7_bit = 1'b0;
            end
            LH_S: begin
                opcode = 7'b0000011;
                funct3 = 3'b001;     
                funct7_bit = 1'b0;
            end
            LB_S: begin
                opcode = 7'b0000011;
                funct3 = 3'b000; 
                funct7_bit = 1'b0;
            end

            //Store instructions
            SW_ST: begin
                opcode= 7'b0100011;
                funct3 = 3'b010;     
                funct7_bit = 1'b0;
            end
            SH_S: begin
                opcode = 7'b0100011;
                funct3 = 3'b001;     
                funct7_bit = 1'b0;
            end
            SB_S: begin
                opcode = 7'b0100011;
                funct3 = 3'b000;      
                funct7_bit = 1'b0;
            end

            //Branch
            BEQ_S: begin
                opcode = 7'b1100011;
                funct3 = 3'b000;
                funct7_bit = 1'b0;
            end

            default: begin
                opcode = 7'b0000000;
                funct3 = 3'b000;
                funct7_bit = 1'b0;
            end
        endcase
    end

endmodule