`timescale 1ns/1ps

module TopLevel_FSM (
    input        clk,
    input        rst,
    input        btn_next,
    input        btn_reset,
    output [15:0] led
);

    //FSM outputs
    wire [6:0] opcode;
    wire [2:0] funct3;
    wire       funct7_bit;
    wire [3:0] state_led;

    FSM_Verifier FSM (
        .clk        (clk),
        .rst        (rst),
        .btn_next   (btn_next),
        .btn_reset  (btn_reset),
        .opcode     (opcode),
        .funct3     (funct3),
        .funct7_bit (funct7_bit),
        .state_led  (state_led)
    );

    //Control path outputs
    wire       RegWrite, ALUSrc, MemRead, MemWrite, MemtoReg, Branch;
    wire [1:0] ALUOp;
    wire [3:0] ALUControlOut;

    MainControl MC (
        .opcode   (opcode),
        .RegWrite (RegWrite),
        .ALUOp    (ALUOp),
        .MemRead  (MemRead),
        .MemWrite (MemWrite),
        .ALUSrc   (ALUSrc),
        .MemtoReg (MemtoReg),
        .Branch   (Branch)
    );

    ALUControl AC (
        .ALUOp        (ALUOp),
        .funct3       (funct3),
        .funct7_bit   (funct7_bit),
        .ALUControlOut(ALUControlOut)
    );

    //LED assignments
    assign led[15]   = RegWrite;
    assign led[14]   = ALUSrc;
    assign led[13]   = MemRead;
    assign led[12]   = MemWrite;
    assign led[11]   = MemtoReg;
    assign led[10]   = Branch;
    assign led[9:8]  = ALUOp;
    assign led[7:4]  = ALUControlOut;
    assign led[3:0]  = state_led;

endmodule